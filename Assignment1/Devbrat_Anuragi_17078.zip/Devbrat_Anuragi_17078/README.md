﻿- Coding Language used : **Python**
- Platform Used: **Jypyter Notebook**
- Instruction to run file:
	- Open Assignment1.ipynb in jypyter notebook.
	- Run these two command to install required library

	
> 
	 pip install -U nltk
	 python -m nltk.downloader all
